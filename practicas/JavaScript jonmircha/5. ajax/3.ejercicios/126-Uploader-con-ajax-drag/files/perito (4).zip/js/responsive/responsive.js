let iconoMenu = document.getElementById('iconoMenu');
let menu = document.querySelector("header nav");
let body = document.querySelector("body");

document.addEventListener('click', e => {
    if(e.target === iconoMenu){
        menu.classList.toggle('mostrarMenu')
        body.classList.toggle('scroolY')
    }
})